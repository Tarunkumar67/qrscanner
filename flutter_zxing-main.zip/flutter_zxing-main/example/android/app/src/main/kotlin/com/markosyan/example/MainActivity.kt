package com.markosyan.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
