import 'flutter_zxing.dart';

Zxing getZxing() => throw UnsupportedError(
    'Cannot create an instance of FlutterZxing on the current platform.');
