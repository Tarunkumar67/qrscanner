package com.markosyan.zxscanner

import org.junit.Assert
import org.junit.Test

class ExampleTest {
    @Test
    fun addition_isCorrect() {
        Assert.assertEquals(4, 2 + 2)
    }
}