package com.markosyan.zxscanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
