const String appName = 'ZXScanner';

/// space between widgets
const double spaceSmall = 2.0;
const double spaceSmall2 = 4.0;
const double spaceMedium = 8.0;
const double spaceDefault = 16.0;
const double spaceLarge = 24.0;
const double spaceLarge2 = 32.0;
const double spaceLarge3 = 40.0;
const double spaceLarge4 = 96.0;

const double spaceMaxWidth = 736.0;
